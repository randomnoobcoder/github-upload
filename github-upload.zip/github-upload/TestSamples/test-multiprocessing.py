from multiprocessing import Pool

inputs = [2, 3, 4]


def func(a):
    return a * 2


if __name__ == "__main__":
    p = Pool(len(inputs))
    output = p.map(func, inputs)
    print(output)
